import sys
import os

def main():
    if len(sys.argv) != 3:
        print("Usage: python <program_name>.py <username> <password>")
        return

    username = sys.argv[1]
    password = sys.argv[2]

    print(f"Logged in as: {username}")

    print("read <filename>")
    print("write <filename> <content>")
    print("append <filename> <content>")
    print("delete <filename>")
    print("quit <filename>")

    while(True):
        command = input("Wypisz komende: ")

        if command.startswith("read "):
            parts = command.split()
            if len(parts) == 2:
                filename = parts[1]
                try:
                    with open(filename, "r") as file:
                        print(file.read())
                except FileNotFoundError:
                    print("Nie znaleziono takiego pliku")
            else:
                print("Zly format komendy")

        elif command.startswith("write "):
            parts = command.split()
            if len(parts) == 3:
                filename, content = parts[1], parts[2]
                with open(filename, "w") as file:
                    file.write(content)
                print("Zostalo zapisane do pliku")
            else:
                print("Zly format komendy")

        elif command.startswith("append "):
            parts = command.split()
            if len(parts) == 3:
                filename, content = parts[1], parts[2]
                with open(filename, "a") as file:
                    file.write(content)
                print("Zostalo dodane do pliku")
            else:
                print("Zly format komend")

        elif command.startswith("delete "):
            parts = command.split()
            if len(parts) == 2:
                filename = parts[1]
                try:
                    os.remove(filename)
                    print("Plik usuniety")
                except FileNotFoundError:
                    print("Nie znaleziono takiego pliku")
            else:
                print("Zly format komend")

        elif command == "quit":
            print("Program wylaczony")
            break

        else:
            print("Nieprawidłowe polecenie.")

if __name__ == "__main__":
    main()
        
        

    