import whois
from datetime import datetime
import time

# Funkcja do pobierania informacji o domenie
def get_domain_info(domain, retries=3):
    attempt = 0
    while attempt < retries:
        try:
            # Wykonanie zapytania WHOIS
            w = whois.whois(domain)
            
            # Jeśli creation_date lub expiration_date to lista, bierzemy tylko pierwszą datę
            creation_date = w.creation_date[0] if isinstance(w.creation_date, list) else w.creation_date
            expiration_date = w.expiration_date[0] if isinstance(w.expiration_date, list) else w.expiration_date
            
            # Jeśli data jest typu datetime, usuwamy strefę czasową i godziny, by była czytelna
            if isinstance(creation_date, datetime):
                creation_date = creation_date.date()
            if isinstance(expiration_date, datetime):
                expiration_date = expiration_date.date()

            return {
                "domain": domain,
                "registrar": w.registrar,
                "creation_date": creation_date,
                "expiration_date": expiration_date
            }
        except Exception as e:
            # Jeśli wystąpił błąd, próbujemy ponownie
            attempt += 1
            print(f"Błąd przy pobieraniu danych dla {domain}. Próba {attempt}/{retries}.")
            if attempt == retries:
                return {
                    "domain": domain,
                    "error": str(e)
                }
            time.sleep(5)  # Odczekaj 5 sekund przed kolejną próbą

# Funkcja do obliczenia liczby dni do wygaśnięcia domeny
def calculate_days_to_expiration(expiration_date):
    if isinstance(expiration_date, list):
        expiration_date = expiration_date[0]
    return (expiration_date - datetime.now().date()).days

# Główna funkcja programu
def main(input_file, output_file):
    # Odczytujemy domeny z pliku wejściowego
    with open(input_file, 'r') as f:
        domains = f.read().splitlines()

    report_lines = []
    for domain in domains:
        # Pobieramy informacje o każdej domenie
        info = get_domain_info(domain)
        
        if "error" in info:
            # Jeśli wystąpił błąd, zapisujemy go do raportu
            report_lines.append(f"{info['domain']} - Error: {info['error']}\n")
        else:
            # Obliczamy dni do wygaśnięcia
            days_to_expiration = calculate_days_to_expiration(info['expiration_date'])
            # Dodajemy informacje do raportu
            report_lines.append(
                f"Domain: {info['domain']}\n"
                f"Registrar: {info['registrar']}\n"
                f"Creation Date: {info['creation_date']}\n"
                f"Expiration Date: {info['expiration_date']}\n"
                f"Days to Expiration: {days_to_expiration}\n"
                "----------------------------------------\n"
            )
        
        # Dodajemy opóźnienie 2 sekundy między zapytaniami
        time.sleep(2)

    # Zapisujemy raport do pliku wyjściowego
    with open(output_file, 'w') as f:
        f.writelines(report_lines)

# Uruchamiamy skrypt
if __name__ == "__main__":
    # Podajemy pełną ścieżkę do pliku wejściowego i wyjściowego
    main(r'C:\Users\themi\OneDrive\Pulpit\New folder (2)\domains.txt', r'C:\Users\themi\OneDrive\Pulpit\New folder (2)\raport.txt')
