document.addEventListener('DOMContentLoaded', function() {
    const cardsArray = [
        { img: './piece-of-cake.png' },
        { img: './piece-of-cake.png' },
        { img: './cake2.png' },
        { img: './cake2.png' },
        { img: './cake.png' },
        { img: './cake.png' },
        { img: './cake-slice.png' },
        { img: './cake-slice.png' },
        { img: './cake3.png' },
        { img: './cake3.png' },
        { img: './cake4.png' },
        { img: './cake4.png' },
        { img: './fruit.png' },
        { img: './fruit.png' },
        { img: './ice-cream.png' },
        { img: './ice-cream.png' },
        { img: './carrot-cake.png' },
        { img: './carrot-cake.png' },
        { img: './strawberry-cake.png' },
        { img: './strawberry-cake.png' },
        { img: './cake5.png' },
        { img: './cake5.png' },
        { img: './cake6.png' },
        { img: './cake6.png' },
        { img: './strawberry.png' },
        { img: './strawberry.png' },
        { img: './cake-piece.png' },
        { img: './cake-piece.png' }
    ];

    const flipSound = new Audio('./flip.mp3');
    const matchSound = new Audio('./match.mp3');
    const winSound = new Audio('./win.mp3');
    const loseSound = new Audio('./lose.mp3');
    let timeLeft = 60; 
    let timerId;
    let gameOver = false;
    const timerDisplay = document.getElementById('timer'); 
    const numCardsInput = document.getElementById('numCards');
    const startGameButton = document.getElementById('startGame');

    let copytab = [];
    const b_e8 = document.getElementById('b_e8');
    const b_e12 = document.getElementById('b_e12');
    const b_e16 = document.getElementById('b_e16');
    const b_e20 = document.getElementById('b_e20');
    const b_e24 = document.getElementById('b_e24');

    function resetGame() {
        clearInterval(timerId); 
        if(copytab.length >= 24){
            timeLeft = 120;
        }
        if(copytab.length > 34){
            timeLeft = 150;
        } if(copytab.length < 24){
            timeLeft = 60;
        }
      
        cardsWon = [];
        gameOver = false;
        updateBoard();
        startTimer();
    }

 
    function changing_elements(event) {
        const klik = event.target;

        if (klik.id === 'b_e12') {
            copytab = repeatArrayElements(cardsArray, 12);
        } else if (klik.id === 'b_e16') {
            copytab = repeatArrayElements(cardsArray, 16);
        } else if (klik.id === 'b_e20') {
            copytab = repeatArrayElements(cardsArray, 20);
        } else if (klik.id === 'b_e8') {
            copytab = repeatArrayElements(cardsArray, 8);
        } else if (klik.id === 'b_e24') {
            copytab = repeatArrayElements(cardsArray, 24);
        }

        resetGame();
    }

  
    function repeatArrayElements(array, numElements) {
        const repeatedArray = [];
        let index = 0;

        while (repeatedArray.length < numElements) {
            repeatedArray.push(array[index]);
            index = (index + 1) % array.length;
        }

        return repeatedArray;
    }

  
    function updateBoard() {
        const gameBoard = document.getElementById('game-board');
        gameBoard.innerHTML = ''; 

        copytab.sort(() => 0.5 - Math.random());

        if (copytab.length >= 24) {
            gameBoard.style.gridTemplateColumns = 'repeat(6, 100px)'; 
        }if(copytab.length > 36){
            gameBoard.style.gridTemplateColumns = 'repeat(8, 100px)';
        }if(copytab.length < 24) {
            gameBoard.style.gridTemplateColumns = 'repeat(4, 100px)'; 
        }

        for (let i = 0; i < copytab.length; i++) {
            const card = document.createElement('div');
            card.classList.add('card');
            card.dataset.id = i;
            card.addEventListener('click', flipCard);
            gameBoard.appendChild(card);
        }
    }

    function startTimer() {
        timerId = setInterval(() => {
            if (timeLeft <= 0 && !gameOver) {
                gameOver = true;
                loseSound.play();
                clearInterval(timerId); 
                setTimeout(() => { 
                    alert('Koniec czasu! Przegrałeś!');
                    resetGame(); 
                }, 2000);
            } else {
                timeLeft--;
                timerDisplay.textContent = `POZOSTAŁY CZAS: ${timeLeft}s`;
            }
        }, 1000);
    }

  
    b_e8.addEventListener('click',changing_elements);
    b_e12.addEventListener('click', changing_elements);
    b_e16.addEventListener('click', changing_elements);
    b_e20.addEventListener('click', changing_elements);
    b_e24.addEventListener('click', changing_elements);

    startGameButton.addEventListener('click', function() {
        let numCards = parseInt(numCardsInput.value, 10);

        if (isNaN(numCards) || numCards < 8 || numCards > 48 || numCards % 2 !== 0) {
            alert("Proszę wybrać parzystą liczbę kart od 8 do 48.");
            return;
        }

        copytab = repeatArrayElements(cardsArray, numCards);
        resetGame();
    });

    copytab = repeatArrayElements(cardsArray, 8);
    copytab.sort(() => 0.5 - Math.random());

    createBoard();
    startTimer();

    function createBoard() {
        const gameBoard = document.getElementById('game-board');
        for (let i = 0; i < copytab.length; i++) {
            const card = document.createElement('div');
            card.classList.add('card');
            card.dataset.id = i;
            card.addEventListener('click', flipCard);
            gameBoard.appendChild(card);
        }
    }

    let chosenCards = [];
    let chosenCardsId = [];
    let cardsWon = [];
    let isChecking = false;

    function flipCard() {
        if (isChecking) return;
        const cardId = this.dataset.id;
        if (chosenCardsId.includes(cardId)) return;
        chosenCards.push(copytab[cardId].img);
        chosenCardsId.push(cardId);
        this.classList.add('flip');
        this.style.backgroundImage = `url(${copytab[cardId].img})`;
        flipSound.play();

        if (chosenCards.length === 2) {
            isChecking = true;
            setTimeout(checkForMatch, 500);
        }
    }

    function checkForMatch() {
        const cards = document.querySelectorAll('.card');
        const [firstId, secondId] = chosenCardsId;

        if (chosenCards[0] === chosenCards[1] && firstId !== secondId) {
            cards[firstId].style.visibility = 'hidden';
            cards[secondId].style.visibility = 'hidden';
            cardsWon.push(chosenCards);
            matchSound.play();
        } else {
            cards[firstId].classList.remove('flip');
            cards[secondId].classList.remove('flip');
            cards[firstId].style.backgroundImage = 'none';
            cards[secondId].style.backgroundImage = 'none';
        }

        chosenCards = [];
        chosenCardsId = [];
        isChecking = false;

        if (cardsWon.length === copytab.length / 2 && timeLeft > 0) {
            winSound.play();
            setTimeout(() => {
                alert('Gratulacje! Wygrałeś!');
                resetGame();
            }, 2000);
        }
    }
});

